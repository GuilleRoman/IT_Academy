package m7exercici2;

import java.sql.Date;

public class Transferencia {
    //Propietats
    CompteCorrent comteOrigen;      // compte corrent origen    
    CompteCorrent compteDesti;     // compte corrent de destí
    Date dataTransacio;           // data de la transacció
    String tipus;                //tipus de transacció
    double import;              //import de la transacció
    
    




    
}
